package org.androidtown.movieproject2;

class result {
    int id;
    String title;
    String title_eng;
    String date;
    float user_rating;
    float audience_rating;
    float reviewer_rating;
    float reservation_rating;
    int reservation_grade;
    int grade;
    String thumb;
    String image;
}
