package org.androidtown.movieproject2.Custom;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.androidtown.movieproject2.R;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {
    ArrayList<MovieList> movieListArrayList=new ArrayList<>();
    public class ViewHolder extends RecyclerView.ViewHolder{
        protected ImageView imageView;
        protected TextView texttitle;
        protected TextView textinfo;
        protected Button detail;
        ViewHolder(View view){
            super(view);
            imageView=view.findViewById(R.id.img1);
            texttitle=view.findViewById(R.id.tv_title);
            textinfo=view.findViewById(R.id.info1);
            detail=view.findViewById(R.id.detail_btn1);
        }
    }
    void addItem(MovieList movieList){
        movieListArrayList.add(movieList);
    }
    void setItem(ArrayList<MovieList> info){
        movieListArrayList=info;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.fragment1, parent, false);

        return new RecyclerAdapter.ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MovieList movieList=movieListArrayList.get(position);
        holder.imageView.setImageResource(movieList.getImage());
        holder.texttitle.setText(movieList.getTitle());
        holder.textinfo.setText(movieList.getInfo());
        holder.detail.setText(movieList.getButtonTitle());
    }

    @Override
    public int getItemCount() {
        return movieListArrayList.size();
    }
}
