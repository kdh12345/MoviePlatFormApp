package org.androidtown.movieproject2.Details;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import org.androidtown.movieproject2.R;

public class MovieListFragment extends Fragment {
    ViewPager viewPager;
    MoviePagerAdapter moviePagerAdapter;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup view=(ViewGroup)inflater.inflate(R.layout.fragment_viewpager,container,false);
        viewPager = view.findViewById(R.id.draw_viewpager);
        viewPager.setOffscreenPageLimit(5);
        moviePagerAdapter = new MoviePagerAdapter(getActivity().getSupportFragmentManager());
        //프래그먼트 1추가
        FirstFragment firstFragment=new FirstFragment();
        moviePagerAdapter.addItem(firstFragment);
        //프래그먼트 2추가
        SecondFragment secondFragment = new SecondFragment();
        moviePagerAdapter.addItem(secondFragment);
        //프래그먼트 3추가
        ThirdFragment thirdFragment = new ThirdFragment();
        moviePagerAdapter.addItem(thirdFragment);
        //프래그먼트 4추가
        FourthFragment fourthFragment = new FourthFragment();
        moviePagerAdapter.addItem(fourthFragment);
        //프래그먼트 5추가
        FifthFragment fifthFragment = new FifthFragment();
        moviePagerAdapter.addItem(fifthFragment);
        viewPager.setAdapter(moviePagerAdapter);
        return view;
    }
}
