package org.androidtown.movieproject2;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.androidtown.movieproject2.DBClasses.MovieDBhelper;
import org.androidtown.movieproject2.Details.MovieListFragment;
import org.androidtown.movieproject2.NetworkCheck.NetworkStatus;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TempActivity extends AppCompatActivity {
    MovieListFragment listFragment;
    Intent intent;
    ArrayList<Movie> arrayList;
    TextView contents;
    Button button;
    //6장
    private MovieDBhelper dbHelper;
    private SQLiteDatabase database;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.temp_activity);
        //listFragment=new MovieListFragment();
        contents=findViewById(R.id.temp_content);
        button=findViewById(R.id.temp_button);
        intent=new Intent(getApplicationContext(),MainActivity.class);
        dbHelper = new MovieDBhelper(getApplicationContext(),"movie.db",null,1);
        database = dbHelper.getWritableDatabase();
        final int Status= NetworkStatus.getConnectivityStatus(getApplicationContext());
        if(Status==NetworkStatus.TYPE_WIFI||Status==NetworkStatus.TYPE_MOBILE){
            if (AppHelper.requestQueue == null)
                AppHelper.requestQueue = Volley.newRequestQueue(getApplicationContext());
            Toast.makeText(this, "요청 성공!!!", Toast.LENGTH_SHORT).show();
            sendRequest();
        }else{
            Toast.makeText(this, "wifi 혹은 모바일 네트워크를 키고 시작하세요", Toast.LENGTH_SHORT).show();
            contents.setText("네트워크 연결 실패!!!!");
            button.setText("네트워크 연결 다시시도");
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                    startActivity(new Intent(getApplicationContext(),TempActivity.class));
                    if(Status==NetworkStatus.TYPE_WIFI||Status==NetworkStatus.TYPE_MOBILE){
                        if (AppHelper.requestQueue == null)
                            AppHelper.requestQueue = Volley.newRequestQueue(getApplicationContext());
                        Toast.makeText(getApplicationContext(), "요청 성공!!!", Toast.LENGTH_SHORT).show();
                        sendRequest();
                    }
                }
            });
        }


    }
    public void sendRequest() {
        String url = "http://boostcourse-appapi.connect.or.kr:10000/movie/readMovieList";
        StringRequest request = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> params=new HashMap<>();
                return params;
            }
        };
        request.setShouldCache(false);
        AppHelper.requestQueue.add(request);
    }
    /*
    * id: 1,
title: "꾼",
title_eng: "The Swindlers",
date: "2017-11-22",
user_rating: 4,
audience_rating: 8.36,
reviewer_rating: 4.33,
reservation_rate: 61.69,
reservation_grade: 1,
grade: 15,
thumb: "http://movie2.phinf.naver.net/20171107_251/1510033896133nWqxG_JPEG/movie_image.jpg?type=m99_141_2",
image: "http://movie.phinf.naver.net/20171107_251/1510033896133nWqxG_JPEG/movie_image.jpg",
    *
    * */
    public void processResponse(String response){
        Gson gson=new Gson();
        MovieListResult movieListResult=gson.fromJson(response,MovieListResult.class);
        if(movieListResult!=null){
            Bundle bundle=new Bundle();
            arrayList=movieListResult.result;
         //   bundle.putParcelableArrayList("movie_data_list",arrayList);
            intent.putParcelableArrayListExtra("movie_data",arrayList);

            //intent.putExtra("to_main_bundle",bundle);
          //  listFragment.setArguments(bundle);
            finish();
            startActivity(intent);
            for(int i=0;i<movieListResult.result.size();i++){
               /* bundle.putInt("ID",movieListResult.result.get(i).id);
                bundle.putString("korea_title",movieListResult.result.get(i).title);
                bundle.putString("english_title",movieListResult.result.get(i).title_eng);
                bundle.putString("Date",movieListResult.result.get(i).date);
                bundle.putFloat("user_rate",movieListResult.result.get(i).user_rating);
                bundle.putFloat("audience_rate",movieListResult.result.get(i).audience_rating);
                bundle.putFloat("review_rate",movieListResult.result.get(i).reviewer_rating);
                bundle.putFloat("reserve_rate",movieListResult.result.get(i).reservation_rate);
                bundle.putFloat("reserve_grade",movieListResult.result.get(i).reservation_grade);
                bundle.putInt("Grade",movieListResult.result.get(i).grade);
                bundle.putString("Thumb",movieListResult.result.get(i).thumb);
                bundle.putString("Images",movieListResult.result.get(i).image);*/

            }
        }
    }
}
