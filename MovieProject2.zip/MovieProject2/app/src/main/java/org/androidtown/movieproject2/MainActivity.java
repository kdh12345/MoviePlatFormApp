package org.androidtown.movieproject2;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.navigation.NavigationView;
import com.google.gson.Gson;

import org.androidtown.movieproject2.Details.DetailFragment;
import org.androidtown.movieproject2.Details.FirstFragment;
import org.androidtown.movieproject2.Details.MovieListFragment;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener, FragmentCallback {

    ViewPager viewPager;
    private DrawerLayout mDrawerLayout;
    private Context context = this;
    private Fragment detailFragment;
    ///////////
    RecyclerView recyclerView;

    NavigationView navigationView;
    MovieListFragment movieListFragment;
    Button button;
    Toolbar toolbar;
    int flag = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drawer_main);
        // FirstFragment firstFragment = new FirstFragment();
        //firstFragment=findViewById(R.id.fr1);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        movieListFragment = new MovieListFragment();
        fragmentTransaction.add(R.id.main_frame, movieListFragment).commit();
        //  fragmentTransaction.add(R.id.contentMain,FirstFragment.newInstance());
        detailFragment = new DetailFragment();
        // fragmentTransaction.add(R.id.main_frame,detailFragment).commit();
        //fragmentTransaction.commit();
        //getSupportFragmentManager().beginTransaction().show(firstFragment).commit();

        ///////////////////////////////////////////
        /*recyclerView=findViewById(R.id.content_recycle);
        LinearLayoutManager layoutManager = new LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        RecyclerAdapter recyclerAdapter=new RecyclerAdapter();
        recyclerView.setAdapter(recyclerAdapter);*/
        ///////////////////////////////////////////
        toolbar = (Toolbar) findViewById(R.id.main_toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("영화 목록");
        /*ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false); // 기존 title 지우기
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 만들기
        actionBar.setHomeAsUpIndicator(R.drawable.ic_hamburger_menu); //뒤로가기 버튼 이미지 지정*/
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        //////
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_hamburger_menu);
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        //////
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        /////////
        if (AppHelper.requestQueue == null)
            AppHelper.requestQueue = Volley.newRequestQueue(getApplicationContext());
        /////////////////////////////
    }
    public void sendRequest() {
        String url = "http://boostcourse-appapi.connect.or.kr:10000/movie/readMovieList";
        StringRequest request = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        processResponse(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> params=new HashMap<>();

                return params;
            }
        };
        request.setShouldCache(false);
        AppHelper.requestQueue.add(request);
    }
    public void processResponse(String response){
        Gson gson=new Gson();
        MovieListResult movieListResult=gson.fromJson(response,MovieListResult.class);
        if(movieListResult!=null){

        }
    }

    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        //FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        switch (menuItem.getItemId()) {
            case R.id.nav_movie_list: {
                Toast.makeText(context, "클릭!!!", Toast.LENGTH_SHORT).show();
                onFragmentSelected(1, null);
            }
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);

        //  mDrawerLayout.closeDrawers();

        return true;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    /* @Override
     public boolean onOptionsItemSelected(MenuItem item) {
         switch (item.getItemId()) {
             case android.R.id.home: { // 왼쪽 상단 버튼 눌렀을 때
                 mDrawerLayout.openDrawer(GravityCompat.START);
                 return true;
             }

         }
         return super.onOptionsItemSelected(item);
     }*/
   /* @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_main_drawer, menu);
        return true;
    }*/
    public void onFragmentSelected(int pos, Bundle bundle) {
        Fragment cur = null;
        if (pos == 0) {
            cur = new DetailFragment();
            detailFragment = cur;
            ///detailFragment.setArguments(bundle);
            toolbar.setTitle("영화 상세");
        } else if (pos == 1) {
            cur = new MovieListFragment();
            movieListFragment = (MovieListFragment) cur;
            toolbar.setTitle("영화 목록");
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, cur).commit();
    }

    public Fragment getFragment() {
        for (Fragment fragment : getSupportFragmentManager().getFragments()) {
            if (fragment.isVisible()) {
                if (fragment instanceof DetailFragment) {
                    return detailFragment;
                }
            }
        }
        return null;
    }
}
