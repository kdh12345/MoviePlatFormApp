package org.androidtown.movieproject2;

import com.android.volley.RequestQueue;

public class AppHelper {
    public static RequestQueue requestQueue;
}
