package org.androidtown.movieproject2.Details;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.navigation.NavigationView;

import org.androidtown.movieproject2.FragmentCallback;
import org.androidtown.movieproject2.MainActivity;
import org.androidtown.movieproject2.R;

import java.util.ArrayList;

public class DetailFragment extends Fragment implements onBackPressedListener {
    public static DetailFragment newInstance(){
        return new DetailFragment();
    }

    ListView listView;
    ArrayList<EvaluationInfo> evaluationInfos = new ArrayList<>();
    //String ID,int image,String Time,float ratingBar,String recommend,int count,String report,
    //                   String evaulates)
    ImageView ThumbsUpView;
    ImageView ThumbsDownView;
    TextView ThumbsUpText;
    TextView ThumbsDownText;
    boolean Like = false;
    boolean Unlike = false;
    RatingBar ratingBar;
    TextView evaluate;
    TextView write;
    TextView PrintAll;
    final static int OK=5;
    // 요청 코드
    public static final int REQUEST_CODE_WRITE = 101;
    public static final int REQUEST_CODE_LOOK = 100;
    RecyclerView recyclerView;
    EvaListAdapter adapter=new EvaListAdapter();
    Context context;
    private DrawerLayout mDrawerLayout;
    private Fragment detailFragment;
    MovieListFragment movieListFragment;
    NavigationView navigationView;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){
        ///super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_detail);
        ViewGroup view=(ViewGroup)inflater.inflate(R.layout.activity_detail,container,false);
        ThumbsUpView = view.findViewById(R.id.thumbs_up);
        ThumbsUpText = view.findViewById(R.id.thumbs_up_text);
        ThumbsDownView = view.findViewById(R.id.thumbs_down);
        ThumbsDownText = view.findViewById(R.id.thumbs_down_text);
        ratingBar = view.findViewById(R.id.rating_evaluates);
        evaluate =view.findViewById(R.id.evaluate_rating);
        ratingBar.setRating(4.5f);
        evaluate.setText("8.2");
        recyclerView = view.findViewById(R.id.evaluation_list);
        // 리사이클러뷰안에 수직방향 리니어레이어를 set

        //  fragmentTransaction.add(R.id.contentMain,FirstFragment.newInstance());
        LinearLayoutManager layoutManager = new LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);

        // 기본 스크롤 기능 안되도록 (모두 보기를 이용하도록 하기 위한 조치)
        recyclerView.setNestedScrollingEnabled(false);
        SetData();
        recyclerView.setAdapter(adapter);
        write = view.findViewById(R.id.write_evaluates);
        PrintAll=view.findViewById(R.id.all_view_btn);
        ThumbsUpView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tmp = ThumbsUpText.getText().toString();
                int LikeCnt = Integer.parseInt(tmp);
                String tmp2 = ThumbsDownText.getText().toString();
                int UnlikeCnt = Integer.parseInt(tmp2);
                if (Like == false) {
                    Like = true;
                    LikeCnt++;
                    ThumbsUpText.setText(LikeCnt + "");
                    ThumbsUpView.setImageResource(R.drawable.ic_thumb_up_selected);
                    if (Unlike == true) {
                        Unlike = false;
                        UnlikeCnt--;
                        ThumbsDownText.setText(UnlikeCnt + "");
                        ThumbsDownView.setImageResource(R.drawable.ic_thumb_down);
                    }
                } else if (Like == true) {
                    Like = false;
                    LikeCnt--;
                    if (LikeCnt < 0)
                        LikeCnt = 0;
                    ThumbsUpText.setText(LikeCnt + "");
                    ThumbsUpView.setImageResource(R.drawable.ic_thumb_up);
                }
            }
        });
        ThumbsDownView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String likeString = ThumbsUpText.getText().toString();
                String unlikeString = ThumbsDownText.getText().toString();

                int likeCount = Integer.parseInt(likeString);
                int unlikeCount = Integer.parseInt(unlikeString);
                if (Unlike == false) {
                    Unlike = true;
                    unlikeCount++;
                    ThumbsDownText.setText(unlikeCount + "");
                    ThumbsDownView.setImageResource(R.drawable.ic_thumb_down_selected);
                    if (Like == true) {
                        Like = false;
                        likeCount--;
                        if (likeCount < 0)
                            likeCount = 0;
                        ThumbsUpText.setText(likeCount + "");
                        ThumbsUpView.setImageResource(R.drawable.ic_thumb_up);
                    }
                } else if (Unlike == true) {
                    unlikeCount--;
                    if (unlikeCount < 0)
                        unlikeCount = 0;
                    ThumbsDownText.setText(unlikeCount + "");
                    ThumbsDownView.setImageResource(R.drawable.ic_thumb_down);
                }
            }
        });
        write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), WriteActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                //finish();
                startActivityForResult(intent, REQUEST_CODE_WRITE);
            }
        });
        PrintAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(), AllListActivity.class);
                // ParcelableArray 로 intent에 담아 전달
                ArrayList<EvaluationInfo> arrayList = adapter.getLists();
                intent.putParcelableArrayListExtra("data", arrayList);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                // finish();
                startActivityForResult(intent, REQUEST_CODE_LOOK);
            }
        });
        /*Toolbar toolbar = (Toolbar)view.findViewById(R.id.detail_toolbar);
        ((AppCompatActivity)getActivity()).setSupportActionBar(toolbar);
        ActionBar actionBar = ((AppCompatActivity)getActivity()).getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false); // 기존 title 지우기
        actionBar.setTitle("영화 상세");
        actionBar.setDisplayHomeAsUpEnabled(true); // 뒤로가기 버튼 만들기
        actionBar.setHomeAsUpIndicator(R.drawable.ic_hamburger_menu); //뒤로가기 버튼 이미지 지정
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        //////
        mDrawerLayout = (DrawerLayout) view.findViewById(R.id.drawer_layout_detail);
        NavigationView navigationView = (NavigationView) view.findViewById(R.id.nav_detail_view);*/
        return view;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_WRITE){
            if (resultCode == OK){
                Toast.makeText(getActivity(),"저장 버튼 클릭",Toast.LENGTH_SHORT).show();
                // Parcelable interface 사용
                /*Bundle bundle = data.getBundleExtra("Bundle");
                evaluationInfos = bundle.getParcelableArrayList("data");
                adapter.addItem(evaluationInfos.get(evaluationInfos.size()-1));*/
                // Parcelable interface 사용
                Bundle bundle = data.getExtras();
                EvaluationInfo userInformation = bundle.getParcelable("UserInfo");
                adapter.addItem(userInformation);
                recyclerView.setAdapter(adapter);
            }else{
                Toast.makeText(getActivity(),"취소 버튼 클릭",Toast.LENGTH_SHORT).show();
            }

        }else if(requestCode == REQUEST_CODE_LOOK){
            if (resultCode == OK){
                // 모두보기에서 작성하기 버튼 눌럿을 때
                Toast.makeText(getActivity(), "작성하기 버튼 클릭",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getActivity(),WriteActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivityForResult(intent, REQUEST_CODE_WRITE);
            }
        }
    }
    public void SetData() {
        adapter.addItem(new EvaluationInfo("id1234", R.drawable.user1,"10분전", 4.0f, "추천", 0,
                "신고하기","11:00",
                "영화보고 난 뒤 남는생각이라곤... 강동원뿐...! 좋은 배우들이었으나 시나리오가 따라오지 못한 영화..." +
                        "기대에 못미쳐 아쉽다. "));
        adapter.addItem(new EvaluationInfo("id777",R.drawable.user1, "5분전", 3.0f, "추천",
                0, "신고하기","11:07",
                "배우들 참 좋은데 영화를 뭐라 설명할길이없네.... "));
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:{ // 왼쪽 상단 버튼 눌렀을 때
                mDrawerLayout.openDrawer(GravityCompat.START);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }
    public void onBackPressed() {
        //  super.onBackPressed();
        getActivity().finish();
        startActivity(new Intent(getActivity(), MainActivity.class));
    }

}
