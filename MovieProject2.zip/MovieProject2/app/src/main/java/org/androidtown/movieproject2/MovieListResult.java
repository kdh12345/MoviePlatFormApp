package org.androidtown.movieproject2;

import java.util.ArrayList;

public class MovieListResult {
    String message;
    int code;
    String resultType;
    int totalCount;
    public ArrayList<Movie> result = new ArrayList<>();
  //  public int status;
}
