package org.androidtown.movieproject2;

import java.util.ArrayList;

public class MovieListResult {
    String message;
    int code;
    String resultType;
    ArrayList<result> resultArrayList = new ArrayList<>();
}
