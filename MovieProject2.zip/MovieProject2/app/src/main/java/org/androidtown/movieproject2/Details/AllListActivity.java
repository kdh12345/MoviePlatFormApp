package org.androidtown.movieproject2.Details;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.androidtown.movieproject2.R;

import java.util.ArrayList;

public class AllListActivity extends AppCompatActivity {

    // EvaluationInfo(String ID,int image,String Time,float ratingBar,String recommend,int count,String report,
    //                   String evaulates)
    ArrayList<EvaluationInfo> mArrayList=new ArrayList<>();
    EvaListAdapter evaListAdapter;
    TextView write;
    RecyclerView mRecyclerView;
    final static int OK=5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_list);
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mArrayList=getIntent().getParcelableArrayListExtra("data");
        mRecyclerView= findViewById(R.id.eva_list);
        mRecyclerView.setNestedScrollingEnabled(false);
        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLinearLayoutManager);
        evaListAdapter = new EvaListAdapter();
        evaListAdapter.setItem(mArrayList);
        evaListAdapter.notifyDataSetChanged();
        mRecyclerView.setAdapter(evaListAdapter);
        write=findViewById(R.id.list_add);
        write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(OK);
                finish();
                //startActivity(new Intent(getApplicationContext(),WriteActivity.class));
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
            default:
                return super.onOptionsItemSelected(item);
        }
    }


}
