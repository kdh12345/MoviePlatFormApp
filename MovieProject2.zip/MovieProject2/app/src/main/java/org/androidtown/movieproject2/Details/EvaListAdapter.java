package org.androidtown.movieproject2.Details;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.androidtown.movieproject2.R;

import java.util.ArrayList;

public class EvaListAdapter extends RecyclerView.Adapter<EvaListAdapter.ViewHolder> {
    ArrayList<EvaluationInfo> EvaLists=new ArrayList<>();
    public class ViewHolder extends RecyclerView.ViewHolder{
        protected TextView textView;
        protected ImageView imageView;
        protected TextView user_times;
        protected TextView ReportTimes;

        protected RatingBar ratingBar;

        protected TextView recommends;

        protected TextView recommendsCounts;

        protected TextView Reports;
        protected TextView Evaluates;
        ViewHolder(View view){
            super(view);
            this.textView=view.findViewById(R.id.user_id);
            this.imageView=view.findViewById(R.id.user_images);
            this.user_times=view.findViewById(R.id.user_times);
            this.ReportTimes=view.findViewById(R.id.report_time);
            this.ratingBar=view.findViewById(R.id.user_rating);
            this.recommends=view.findViewById(R.id.recommends);
            this.recommendsCounts=view.findViewById(R.id.recommends_count);
            this.Reports=view.findViewById(R.id.user_report);
            this.Evaluates=view.findViewById(R.id.user_evaluate);
        }
    }
    void addItem(EvaluationInfo info){
        EvaLists.add(info);
    }
    void setItem(ArrayList<EvaluationInfo> info){
        EvaLists=info;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.evalutionlist, parent, false);

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
          EvaluationInfo evaluationInfo=EvaLists.get(position);
           holder.textView.setText(evaluationInfo.getID());
           holder.imageView.setImageResource(evaluationInfo.getImage());
           holder.user_times.setText(evaluationInfo.getTime());
           holder.ReportTimes.setText(evaluationInfo.getTime());
           holder.ratingBar.setRating(evaluationInfo.getRatingBar());
           holder.recommends.setText(evaluationInfo.getRecommend());
           String tmp=evaluationInfo.getCount()+"";
           holder.recommendsCounts.setText(tmp);
           holder.Reports.setText(evaluationInfo.getReport());
           holder.Evaluates.setText(evaluationInfo.getEvaulate());
    }

    @Override
    public int getItemCount() {
        return EvaLists.size();
    }

    public ArrayList<EvaluationInfo> getLists(){
        return EvaLists;
    }
    public EvaluationInfo getItem(int position) {
        return EvaLists.get(position);
    }
}
