package org.androidtown.movieproject2.Details;

public interface onBackPressedListener {
    void onBackPressed();
}
