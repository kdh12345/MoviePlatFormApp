package org.androidtown.movieproject2.Details;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import org.androidtown.movieproject2.R;

public class FourthFragment extends Fragment {
    Button detail;
    FourthFragment(){

    }
    public static FourthFragment newInstance() {
        Bundle args = new Bundle();
        FourthFragment fourthFragment=new FourthFragment();

        return fourthFragment;
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup view=(ViewGroup)inflater.inflate(R.layout.fragment4,container,false);

        return view;
    }
}
