package org.androidtown.movieproject2.Details;

import android.os.Parcel;
import android.os.Parcelable;

public class EvaluationInfo  implements Parcelable{
    String Id;
    int image;
    String times;
    float rating;
    String recommend;
    int count;
    String report;
    String report_time;
    String evaulates;
    EvaluationInfo(String Id,int image,String times,float ratingBar,String recommend,int count,String report
            ,String report_time,String evaulates){
        this.Id=Id;
        this.image=image;
        this.times=times;
        this.rating=ratingBar;
        this.recommend=recommend;
        this.count=count;
        this.report=report;
        this.report_time=report_time;
        this.evaulates=evaulates;
    }
    public EvaluationInfo(Parcel src){
        Id = src.readString();
        image=src.readInt();
        times = src.readString();
        recommend=src.readString();
        report=src.readString();
        report_time=src.readString();
        count=src.readInt();
        evaulates = src.readString();
        rating = src.readFloat();
    }
    public static final Creator CREATOR = new Creator(){
        public EvaluationInfo createFromParcel(Parcel in){
            return new EvaluationInfo(in);
        }
        public EvaluationInfo[] newArray(int size){
            return new EvaluationInfo[size];
        }
    };
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(Id);
        dest.writeInt(image);
        dest.writeString(times);
        dest.writeString(recommend);
        dest.writeString(report);
        dest.writeString(report_time);
        dest.writeInt(count);
        dest.writeString(evaulates);
        dest.writeFloat(rating);
    }
    @Override
    public int describeContents() {
        return 0;
    }
    public String getID() {
        return Id;
    }

    public void setID(String ID) {
        this.Id = ID;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getTime() {
        return times;
    }

    public void setTime(String time) {
        times = time;
    }

    public float getRatingBar() {
        return rating;
    }

    public void setRatingBar(float rating) {
        this.rating = rating;
    }

    public String getRecommend() {
        return recommend;
    }

    public void setRecommend(String recommend) {
        this.recommend = recommend;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getReport() {
        return report;
    }

    public void setReport(String report) {
        this.report = report;
    }

    public String getEvaulate() {
        return evaulates;
    }

    public void setEvaulate(String evaulates) {
        this.evaulates = evaulates;
    }
}
