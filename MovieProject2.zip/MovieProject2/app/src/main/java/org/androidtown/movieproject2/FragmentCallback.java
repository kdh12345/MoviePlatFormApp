package org.androidtown.movieproject2;

import android.os.Bundle;

public interface FragmentCallback {
    public void onFragmentSelected(int pos, Bundle bundl,Movie movie);
}
