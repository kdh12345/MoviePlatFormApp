package org.androidtown.movieproject2.CustomFragment;

import androidx.fragment.app.Fragment;

public class customFragment1 extends Fragment {

}
