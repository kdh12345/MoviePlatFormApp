package org.androidtown.movieproject2.Details;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import org.androidtown.movieproject2.R;

public class SecondFragment extends Fragment {
    Button detail;
    SecondFragment(){

    }
    public static SecondFragment newInstance() {
        Bundle args = new Bundle();
        SecondFragment secondFragment=new SecondFragment();

        return secondFragment;
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup view=(ViewGroup)inflater.inflate(R.layout.fragment2,container,false);

        return view;
    }
}
