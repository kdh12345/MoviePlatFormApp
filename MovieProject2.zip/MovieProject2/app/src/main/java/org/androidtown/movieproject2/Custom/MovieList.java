package org.androidtown.movieproject2.Custom;

import android.widget.Button;

public class MovieList {
    int image;
    String title;
    String info;
    String ButtonTitle;
    MovieList(int image,String title,String info,String buttonTitle){
        this.image=image;
        this.title=title;
        this.info=info;
        this.ButtonTitle=buttonTitle;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getButtonTitle() {
        return ButtonTitle;
    }

    public void setButton(String buttonTitle) {
        this.ButtonTitle=buttonTitle;
    }
}
