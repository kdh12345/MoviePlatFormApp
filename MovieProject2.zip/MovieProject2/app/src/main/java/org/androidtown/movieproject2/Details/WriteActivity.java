package org.androidtown.movieproject2.Details;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.androidtown.movieproject2.Details.EvaluationInfo;
import org.androidtown.movieproject2.MainActivity;
import org.androidtown.movieproject2.R;

public class WriteActivity extends AppCompatActivity {
    // EvaluationInfo(String ID,int image,String Time,float ratingBar,String recommend,int count,String report,
    //                   String evaulates){
    final static int OK=5;
    RatingBar ratingBar;
    EditText edit;
    TextView store;
    TextView undo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write);
        //ratingBar=findViewById(R.id.rating_set);
        //edit=findViewById(R.id.edit_rating);
        store=findViewById(R.id.store);
        undo=findViewById(R.id.undo);
        store.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ratingBar = findViewById(R.id.rating_set);
                edit = findViewById(R.id.edit_rating);

                float rating = ratingBar.getRating();
                String evaluation = edit.getText().toString();
                Intent intent = new Intent();
                // 이름이랑 시간은 로그인 정보에서 받아야할듯..
                EvaluationInfo info=new EvaluationInfo("kim1234",R.drawable.user1,"5분전",rating,"추천하기",0,"신고하기","12:00",
                        evaluation);
                intent.putExtra("UserInfo",info);
                setResult(OK, intent);
                finish();
            }
        });
        undo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Intent intent=new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
